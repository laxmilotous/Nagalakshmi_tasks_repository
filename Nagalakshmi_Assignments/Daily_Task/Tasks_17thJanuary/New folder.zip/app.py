import mysql.connector
import json

my_conn = mysql.connector.connect(
    host='13.233.83.152',
    user='peter',
    password='Pass_123',
    database='flask'

)

print(my_conn)


def lambda_handler(event, context):
    http_method = event['context']['http-method']
    print(event)
    if http_method == 'POST':
        post_cursor = my_conn.cursor()
        sno = event['body-json']['sno']
        name = event['body-json']['name']
        city = event['body-json']['city']
        post_cursor.execute(
            "insert into people (sno,name,city) values (%s,%s,%s)", (sno, name, city))
        my_conn.commit()
        return {
            'statusCode': 200,
            'body': json.dumps('record inserted sucessfully!!')
        }
    else:
        mycursor = my_conn.cursor()
        mycursor.execute("select * from people")
        return mycursor.fetchall()
